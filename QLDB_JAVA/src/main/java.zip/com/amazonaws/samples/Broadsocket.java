package com.amazonaws.samples;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.Session;
import javax.websocket.server.ServerEndpoint;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import com.amazon.ion.IonStruct;

import software.amazon.qldb.QldbSession;
import software.amazon.qldb.Result;
import software.amazon.qldb.TransactionExecutor;


@ServerEndpoint("/broadcasting")
public class Broadsocket {

    public static final Logger log = LoggerFactory.getLogger(Createtable.class);


	private static Set<Session> clients = Collections.synchronizedSet(new HashSet<Session>());
	 public static void insertrecord(TransactionExecutor txn,JSONObject jsonObj)
	    {
	    	
	    	final String query = String.format("INSERT INTO RECORD"
	    	 		+ "{ 'student_id' : '%s',"
	    	 		+ "'host_id' : '%s',"
	    	 		+ "'authorizer_id' : '%s',"
	    	 		+ "'student_organization' : '%s',"
	    	 		+ "'contest_title' : '%s',"
	    	 		+ "'contest_category' : '%s',"
	    	 		+ "'date' : '%s',"
	    	 		+ "'project_title':'%s',"
	    	 		+ "'awarded' : '%s',"
	    	 		+ "'prize_name' : '%s' "	    	 		
	    	 		+ " }",jsonObj.get("student_id"),jsonObj.get("host_id"),jsonObj.get("authorizer_id"),
	    	 		jsonObj.get("student_organization"),jsonObj.get("contest_title"),jsonObj.get("contest_category"),
	    	 		jsonObj.get("date"),jsonObj.get( "project_title"),
	    	 		jsonObj.get("awarded"),jsonObj.get( "prize_name"));
	    	 System.out.printf("%s", query);
	    	 final Result result = txn.execute(query);
	    	
	    }

	public static void main(String[] args)
	{
		
		
		String jsonData="{"
					+ "\"student_id\": \"qwe12\","
			   		+ "\"host_id\": \"qwert1163\","
			   		+ "\"authorizer_id\": \"qwe123\","
			   		+ "\"student_organization\": \"KNU\","
			   		+ "\"contest_title\": \"Block_Chain\","
			   		+ "\"contest_category\": \"software/develop\","
			   		+ "\"date\": \"2019-01-01\","
			   		+ "\"project_title\": \"qwe\","
			   		+ "\"awarded\": true,"
			   		+ "\"prize_name\": \"first\""
			   		+ "	}";
				
		try  (QldbSession qldbSession = ConnectToLedger.createQldbSession()) { 
			JSONParser jsonParse = new JSONParser(); 
			//JSONParse�� json�����͸� �־� �Ľ��� ���� JSONObject�� ��ȯ�Ѵ�. 
			JSONObject jsonObj = (JSONObject) jsonParse.parse(jsonData);
		    qldbSession.execute(txn -> {
            	insertrecord(txn,jsonObj);
               }, (retryAttempt) -> log.info("Retrying due to OCC conflict..."));
            
			//JSONObject���� PersonsArray�� get�Ͽ� JSONArray�� �����Ѵ�. 
			System.out.println(jsonObj.get("student_id"));
		
		}catch (ParseException e) 
		{ 
			e.printStackTrace(); 
		}
		
		
		  
		  
		  
	}
	
		
	  
	   
	   public static List<IonStruct> toIonStructs(final Result result) {
	        final List<IonStruct> documentList = new ArrayList<>();
	        result.iterator().forEachRemaining(row -> documentList.add((IonStruct) row));
	        return documentList;
	    }
	    
	    public static void printDocuments(final List<IonStruct> documents) {
	        documents.forEach(row -> System.out.printf(row.toPrettyString()));
	    }
	    public static void findVehiclesForOwner(final TransactionExecutor txn) {
	        final String query = "SELECT * FROM RECORD";
			
			//log.info("List of Vehicles for owner with GovId: {}...", govId);
			List<IonStruct> documents = toIonStructs(txn.execute(query));
			System.out.println("Execute");
			printDocuments(documents);
		}
		
	

	@OnMessage

	public void onMessage(String message, Session session) throws IOException {

		System.out.println(message);

		synchronized (clients) {

			// Iterate over the connected sessions

			// and broadcast the received message

			for (Session client : clients) {

				if (!client.equals(session)) {

					client.getBasicRemote().sendText(message);

				}

			}

		}

	}



	@OnOpen

	public void onOpen(Session session) {

		// Add session to the connected sessions set

		System.out.println(session);

		clients.add(session);

	}



	@OnClose

	public void onClose(Session session) {

		// Remove session from the connected sessions set

		clients.remove(session);

	}

}